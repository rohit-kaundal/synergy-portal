angular.module('mwFormBuilder', ['ngSanitize','ng-sortable', 'pascalprecht.translate']);
